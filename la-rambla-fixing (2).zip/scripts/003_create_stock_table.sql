-- Create stock/inventory table
CREATE TABLE IF NOT EXISTS public.stock (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  category TEXT,
  quantity INTEGER NOT NULL DEFAULT 0,
  min_quantity INTEGER DEFAULT 0, -- Minimum stock alert level
  price DECIMAL(10,2),
  supplier TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Enable RLS
ALTER TABLE public.stock ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "stock_select_own" ON public.stock FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "stock_insert_own" ON public.stock FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "stock_update_own" ON public.stock FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "stock_delete_own" ON public.stock FOR DELETE USING (auth.uid() = user_id);

-- Create updated_at trigger
CREATE TRIGGER update_stock_updated_at BEFORE UPDATE ON public.stock
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
