-- Create repairs table with custom fields as per requirements
CREATE TABLE IF NOT EXISTS public.repairs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  device TEXT NOT NULL, -- Hand-writable with autocomplete
  diagnostico TEXT, -- Diagnosis field with autocomplete for common repairs
  observaciones TEXT, -- Renamed from problem description
  coste_reparacion DECIMAL(10,2), -- Single cost field
  estado TEXT NOT NULL DEFAULT 'En Reparación', -- Repair state
  notas_tecnico TEXT, -- Technician notes (not visible to client)
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Enable RLS
ALTER TABLE public.repairs ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "repairs_select_own" ON public.repairs FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "repairs_insert_own" ON public.repairs FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "repairs_update_own" ON public.repairs FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "repairs_delete_own" ON public.repairs FOR DELETE USING (auth.uid() = user_id);

-- Create updated_at trigger
CREATE TRIGGER update_repairs_updated_at BEFORE UPDATE ON public.repairs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
