-- Updated to create default settings that will be copied for each user when they first access settings
-- Create a function to seed default settings for a user
CREATE OR REPLACE FUNCTION seed_user_settings(target_user_id UUID)
RETURNS VOID AS $$
BEGIN
  -- Insert default repair states for the user
  INSERT INTO public.settings (setting_type, setting_key, setting_value, is_default, user_id)
  SELECT 
    'repair_states',
    unnest(ARRAY['reparado', 'entregado', 'cursando_garantia', 'laboratorio', 'sin_reparacion', 'en_reparacion']),
    unnest(ARRAY['Reparado', 'Entregado', 'Cursando Garantía', 'Laboratorio', 'Sin Reparación', 'En Reparación']),
    true,
    target_user_id
  ON CONFLICT (user_id, setting_type, setting_key) DO NOTHING;

  -- Insert common diagnosis types for the user
  INSERT INTO public.settings (setting_type, setting_key, setting_value, is_default, user_id)
  SELECT 
    'diagnosis_types',
    unnest(ARRAY[
      'pantalla_rota', 'bateria_agotada', 'no_enciende', 'problema_carga', 
      'altavoz_no_funciona', 'microfono_no_funciona', 'camara_no_funciona',
      'tactil_no_responde', 'agua_derramada', 'golpe_caida'
    ]),
    unnest(ARRAY[
      'Pantalla rota', 'Batería agotada', 'No enciende', 'Problema de carga',
      'Altavoz no funciona', 'Micrófono no funciona', 'Cámara no funciona',
      'Táctil no responde', 'Agua derramada', 'Golpe/Caída'
    ]),
    true,
    target_user_id
  ON CONFLICT (user_id, setting_type, setting_key) DO NOTHING;

  -- Insert common device models for the user
  INSERT INTO public.settings (setting_type, setting_key, setting_value, is_default, user_id)
  SELECT 
    'device_models',
    unnest(ARRAY[
      'iphone_15_pro', 'iphone_15', 'iphone_14_pro', 'iphone_14', 'iphone_13',
      'samsung_s24', 'samsung_s23', 'samsung_a54', 'xiaomi_13', 'huawei_p60'
    ]),
    unnest(ARRAY[
      'iPhone 15 Pro', 'iPhone 15', 'iPhone 14 Pro', 'iPhone 14', 'iPhone 13',
      'Samsung Galaxy S24', 'Samsung Galaxy S23', 'Samsung Galaxy A54', 'Xiaomi 13', 'Huawei P60'
    ]),
    true,
    target_user_id
  ON CONFLICT (user_id, setting_type, setting_key) DO NOTHING;
END;
$$ LANGUAGE plpgsql;
