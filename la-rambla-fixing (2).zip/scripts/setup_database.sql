-- Create all tables for La Rambla Fixing repair management system

-- Enable RLS
ALTER DATABASE postgres SET "app.jwt_secret" TO 'your-jwt-secret';

-- Create clients table
CREATE TABLE IF NOT EXISTS public.clients (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  phone VARCHAR(50),
  address TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create repairs table
CREATE TABLE IF NOT EXISTS public.repairs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE,
  device VARCHAR(255) NOT NULL,
  diagnostico TEXT,
  observaciones TEXT,
  coste_reparacion DECIMAL(10,2),
  estado VARCHAR(50) DEFAULT 'En Reparación',
  notas_tecnico TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create stock table
CREATE TABLE IF NOT EXISTS public.stock (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(100),
  quantity INTEGER DEFAULT 0,
  min_quantity INTEGER DEFAULT 0,
  price DECIMAL(10,2),
  supplier VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create settings table
CREATE TABLE IF NOT EXISTS public.settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  setting_type VARCHAR(50) NOT NULL,
  setting_key VARCHAR(100) NOT NULL,
  setting_value TEXT NOT NULL,
  is_default BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, setting_type, setting_key)
);

-- Create profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  business_name VARCHAR(255),
  email VARCHAR(255),
  phone VARCHAR(50),
  address TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.repairs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view own clients" ON public.clients FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own clients" ON public.clients FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own clients" ON public.clients FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own clients" ON public.clients FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "Users can view own repairs" ON public.repairs FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own repairs" ON public.repairs FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own repairs" ON public.repairs FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own repairs" ON public.repairs FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "Users can view own stock" ON public.stock FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own stock" ON public.stock FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own stock" ON public.stock FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own stock" ON public.stock FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "Users can view own settings" ON public.settings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own settings" ON public.settings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own settings" ON public.settings FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own settings" ON public.settings FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can delete own profile" ON public.profiles FOR DELETE USING (auth.uid() = id);

-- Insert default settings
INSERT INTO public.settings (user_id, setting_type, setting_key, setting_value, is_default) VALUES
  (auth.uid(), 'repair_states', 'En Reparación', 'En Reparación', true),
  (auth.uid(), 'repair_states', 'Reparado', 'Reparado', true),
  (auth.uid(), 'repair_states', 'Entregado', 'Entregado', true),
  (auth.uid(), 'repair_states', 'Cursando Garantía', 'Cursando Garantía', true),
  (auth.uid(), 'repair_states', 'Laboratorio', 'Laboratorio', true),
  (auth.uid(), 'repair_states', 'Sin Reparación', 'Sin Reparación', true),
  (auth.uid(), 'diagnosis_types', 'Pantalla rota', 'Pantalla rota', true),
  (auth.uid(), 'diagnosis_types', 'Batería defectuosa', 'Batería defectuosa', true),
  (auth.uid(), 'diagnosis_types', 'Puerto de carga dañado', 'Puerto de carga dañado', true),
  (auth.uid(), 'diagnosis_types', 'Altavoz no funciona', 'Altavoz no funciona', true),
  (auth.uid(), 'diagnosis_types', 'Cámara defectuosa', 'Cámara defectuosa', true),
  (auth.uid(), 'device_models', 'iPhone 14', 'iPhone 14', true),
  (auth.uid(), 'device_models', 'iPhone 13', 'iPhone 13', true),
  (auth.uid(), 'device_models', 'Samsung Galaxy S23', 'Samsung Galaxy S23', true),
  (auth.uid(), 'device_models', 'Samsung Galaxy S22', 'Samsung Galaxy S22', true),
  (auth.uid(), 'device_models', 'Xiaomi Redmi Note 12', 'Xiaomi Redmi Note 12', true)
ON CONFLICT (user_id, setting_type, setting_key) DO NOTHING;

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, business_name, email)
  VALUES (NEW.id, 'Mi Negocio', NEW.email);
  
  -- Insert default settings for new user
  INSERT INTO public.settings (user_id, setting_type, setting_key, setting_value, is_default) VALUES
    (NEW.id, 'repair_states', 'En Reparación', 'En Reparación', true),
    (NEW.id, 'repair_states', 'Reparado', 'Reparado', true),
    (NEW.id, 'repair_states', 'Entregado', 'Entregado', true),
    (NEW.id, 'repair_states', 'Cursando Garantía', 'Cursando Garantía', true),
    (NEW.id, 'repair_states', 'Laboratorio', 'Laboratorio', true),
    (NEW.id, 'repair_states', 'Sin Reparación', 'Sin Reparación', true),
    (NEW.id, 'diagnosis_types', 'Pantalla rota', 'Pantalla rota', true),
    (NEW.id, 'diagnosis_types', 'Batería defectuosa', 'Batería defectuosa', true),
    (NEW.id, 'diagnosis_types', 'Puerto de carga dañado', 'Puerto de carga dañado', true),
    (NEW.id, 'diagnosis_types', 'Altavoz no funciona', 'Altavoz no funciona', true),
    (NEW.id, 'diagnosis_types', 'Cámara defectuosa', 'Cámara defectuosa', true),
    (NEW.id, 'device_models', 'iPhone 14', 'iPhone 14', true),
    (NEW.id, 'device_models', 'iPhone 13', 'iPhone 13', true),
    (NEW.id, 'device_models', 'Samsung Galaxy S23', 'Samsung Galaxy S23', true),
    (NEW.id, 'device_models', 'Samsung Galaxy S22', 'Samsung Galaxy S22', true),
    (NEW.id, 'device_models', 'Xiaomi Redmi Note 12', 'Xiaomi Redmi Note 12', true)
  ON CONFLICT (user_id, setting_type, setting_key) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
