-- Creating comprehensive database initialization script
-- Create clients table
CREATE TABLE IF NOT EXISTS public.clients (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  phone VARCHAR(50),
  address TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Create repairs table with custom fields
CREATE TABLE IF NOT EXISTS public.repairs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE NOT NULL,
  device VARCHAR(255) NOT NULL,
  diagnostico TEXT,
  observaciones TEXT,
  coste_reparacion DECIMAL(10,2) DEFAULT 0,
  estado VARCHAR(50) DEFAULT 'En Reparación',
  notas_tecnico TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Create stock table
CREATE TABLE IF NOT EXISTS public.stock (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(100),
  quantity INTEGER DEFAULT 0,
  min_quantity INTEGER DEFAULT 0,
  price DECIMAL(10,2) DEFAULT 0,
  supplier VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Fixed settings table by removing problematic UNIQUE constraint with COALESCE
CREATE TABLE IF NOT EXISTS public.settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  category VARCHAR(100) NOT NULL,
  key VARCHAR(100) NOT NULL,
  value TEXT NOT NULL,
  is_default BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Create unique index separately to handle the constraint properly
CREATE UNIQUE INDEX IF NOT EXISTS settings_unique_key 
ON public.settings (category, key, COALESCE(user_id, '00000000-0000-0000-0000-000000000000'::uuid));

-- Create profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  business_name VARCHAR(255),
  email VARCHAR(255),
  phone VARCHAR(50),
  address TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.repairs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view own clients" ON public.clients FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own clients" ON public.clients FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own clients" ON public.clients FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own clients" ON public.clients FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "Users can view own repairs" ON public.repairs FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own repairs" ON public.repairs FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own repairs" ON public.repairs FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own repairs" ON public.repairs FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "Users can view own stock" ON public.stock FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own stock" ON public.stock FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own stock" ON public.stock FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own stock" ON public.stock FOR DELETE USING (auth.uid() = user_id);

-- Updated settings policies to handle both user-specific and default settings
CREATE POLICY "Users can view settings" ON public.settings FOR SELECT USING (auth.uid() = user_id OR user_id IS NULL);
CREATE POLICY "Users can insert own settings" ON public.settings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own settings" ON public.settings FOR UPDATE USING (auth.uid() = user_id AND is_default = false);
CREATE POLICY "Users can delete own settings" ON public.settings FOR DELETE USING (auth.uid() = user_id AND is_default = false);

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can delete own profile" ON public.profiles FOR DELETE USING (auth.uid() = id);

-- Insert default settings with NULL user_id to avoid foreign key constraint
INSERT INTO public.settings (category, key, value, is_default, user_id) VALUES
('repair_states', 'En Reparación', 'En Reparación', true, NULL),
('repair_states', 'Reparado', 'Reparado', true, NULL),
('repair_states', 'Entregado', 'Entregado', true, NULL),
('repair_states', 'Cursando Garantía', 'Cursando Garantía', true, NULL),
('repair_states', 'Laboratorio', 'Laboratorio', true, NULL),
('repair_states', 'Sin Reparación', 'Sin Reparación', true, NULL),
('diagnosis_types', 'Pantalla rota', 'Pantalla rota', true, NULL),
('diagnosis_types', 'Batería agotada', 'Batería agotada', true, NULL),
('diagnosis_types', 'Problema de carga', 'Problema de carga', true, NULL),
('diagnosis_types', 'Daño por agua', 'Daño por agua', true, NULL),
('diagnosis_types', 'Problema de software', 'Problema de software', true, NULL),
('device_models', 'iPhone 15 Pro', 'iPhone 15 Pro', true, NULL),
('device_models', 'iPhone 15', 'iPhone 15', true, NULL),
('device_models', 'Samsung Galaxy S24', 'Samsung Galaxy S24', true, NULL),
('device_models', 'Samsung Galaxy S23', 'Samsung Galaxy S23', true, NULL),
('device_models', 'MacBook Pro', 'MacBook Pro', true, NULL),
('device_models', 'PlayStation 5', 'PlayStation 5', true, NULL)
ON CONFLICT DO NOTHING;

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email)
  VALUES (NEW.id, NEW.email);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
