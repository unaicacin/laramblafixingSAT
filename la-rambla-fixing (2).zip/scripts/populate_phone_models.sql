-- Adding comprehensive list of phone models for autocomplete
-- Populate device models with comprehensive phone model list
INSERT INTO settings (setting_type, setting_key, setting_value, user_id) VALUES
-- iPhone Models
('device_models', 'iphone_15_pro_max', 'iPhone 15 Pro Max', NULL),
('device_models', 'iphone_15_pro', 'iPhone 15 Pro', NULL),
('device_models', 'iphone_15_plus', 'iPhone 15 Plus', NULL),
('device_models', 'iphone_15', 'iPhone 15', NULL),
('device_models', 'iphone_14_pro_max', 'iPhone 14 Pro Max', NULL),
('device_models', 'iphone_14_pro', 'iPhone 14 Pro', NULL),
('device_models', 'iphone_14_plus', 'iPhone 14 Plus', NULL),
('device_models', 'iphone_14', 'iPhone 14', NULL),
('device_models', 'iphone_13_pro_max', 'iPhone 13 Pro Max', NULL),
('device_models', 'iphone_13_pro', 'iPhone 13 Pro', NULL),
('device_models', 'iphone_13_mini', 'iPhone 13 mini', NULL),
('device_models', 'iphone_13', 'iPhone 13', NULL),
('device_models', 'iphone_12_pro_max', 'iPhone 12 Pro Max', NULL),
('device_models', 'iphone_12_pro', 'iPhone 12 Pro', NULL),
('device_models', 'iphone_12_mini', 'iPhone 12 mini', NULL),
('device_models', 'iphone_12', 'iPhone 12', NULL),
('device_models', 'iphone_11_pro_max', 'iPhone 11 Pro Max', NULL),
('device_models', 'iphone_11_pro', 'iPhone 11 Pro', NULL),
('device_models', 'iphone_11', 'iPhone 11', NULL),
('device_models', 'iphone_xr', 'iPhone XR', NULL),
('device_models', 'iphone_xs_max', 'iPhone XS Max', NULL),
('device_models', 'iphone_xs', 'iPhone XS', NULL),
('device_models', 'iphone_x', 'iPhone X', NULL),
('device_models', 'iphone_8_plus', 'iPhone 8 Plus', NULL),
('device_models', 'iphone_8', 'iPhone 8', NULL),
('device_models', 'iphone_7_plus', 'iPhone 7 Plus', NULL),
('device_models', 'iphone_7', 'iPhone 7', NULL),
('device_models', 'iphone_se_2022', 'iPhone SE (2022)', NULL),
('device_models', 'iphone_se_2020', 'iPhone SE (2020)', NULL),

-- Samsung Galaxy S Series
('device_models', 'galaxy_s24_ultra', 'Samsung Galaxy S24 Ultra', NULL),
('device_models', 'galaxy_s24_plus', 'Samsung Galaxy S24+', NULL),
('device_models', 'galaxy_s24', 'Samsung Galaxy S24', NULL),
('device_models', 'galaxy_s23_ultra', 'Samsung Galaxy S23 Ultra', NULL),
('device_models', 'galaxy_s23_plus', 'Samsung Galaxy S23+', NULL),
('device_models', 'galaxy_s23', 'Samsung Galaxy S23', NULL),
('device_models', 'galaxy_s22_ultra', 'Samsung Galaxy S22 Ultra', NULL),
('device_models', 'galaxy_s22_plus', 'Samsung Galaxy S22+', NULL),
('device_models', 'galaxy_s22', 'Samsung Galaxy S22', NULL),
('device_models', 'galaxy_s21_ultra', 'Samsung Galaxy S21 Ultra', NULL),
('device_models', 'galaxy_s21_plus', 'Samsung Galaxy S21+', NULL),
('device_models', 'galaxy_s21', 'Samsung Galaxy S21', NULL),
('device_models', 'galaxy_s20_ultra', 'Samsung Galaxy S20 Ultra', NULL),
('device_models', 'galaxy_s20_plus', 'Samsung Galaxy S20+', NULL),
('device_models', 'galaxy_s20', 'Samsung Galaxy S20', NULL),

-- Samsung Galaxy Note Series
('device_models', 'galaxy_note_20_ultra', 'Samsung Galaxy Note 20 Ultra', NULL),
('device_models', 'galaxy_note_20', 'Samsung Galaxy Note 20', NULL),
('device_models', 'galaxy_note_10_plus', 'Samsung Galaxy Note 10+', NULL),
('device_models', 'galaxy_note_10', 'Samsung Galaxy Note 10', NULL),

-- Samsung Galaxy A Series
('device_models', 'galaxy_a54', 'Samsung Galaxy A54', NULL),
('device_models', 'galaxy_a34', 'Samsung Galaxy A34', NULL),
('device_models', 'galaxy_a24', 'Samsung Galaxy A24', NULL),
('device_models', 'galaxy_a14', 'Samsung Galaxy A14', NULL),
('device_models', 'galaxy_a53', 'Samsung Galaxy A53', NULL),
('device_models', 'galaxy_a33', 'Samsung Galaxy A33', NULL),
('device_models', 'galaxy_a23', 'Samsung Galaxy A23', NULL),
('device_models', 'galaxy_a13', 'Samsung Galaxy A13', NULL),

-- Samsung Galaxy Z Series (Foldables)
('device_models', 'galaxy_z_fold_5', 'Samsung Galaxy Z Fold 5', NULL),
('device_models', 'galaxy_z_flip_5', 'Samsung Galaxy Z Flip 5', NULL),
('device_models', 'galaxy_z_fold_4', 'Samsung Galaxy Z Fold 4', NULL),
('device_models', 'galaxy_z_flip_4', 'Samsung Galaxy Z Flip 4', NULL),

-- Google Pixel Series
('device_models', 'pixel_8_pro', 'Google Pixel 8 Pro', NULL),
('device_models', 'pixel_8', 'Google Pixel 8', NULL),
('device_models', 'pixel_7_pro', 'Google Pixel 7 Pro', NULL),
('device_models', 'pixel_7', 'Google Pixel 7', NULL),
('device_models', 'pixel_7a', 'Google Pixel 7a', NULL),
('device_models', 'pixel_6_pro', 'Google Pixel 6 Pro', NULL),
('device_models', 'pixel_6', 'Google Pixel 6', NULL),
('device_models', 'pixel_6a', 'Google Pixel 6a', NULL),
('device_models', 'pixel_5', 'Google Pixel 5', NULL),
('device_models', 'pixel_4a', 'Google Pixel 4a', NULL),

-- Xiaomi Series
('device_models', 'xiaomi_14_ultra', 'Xiaomi 14 Ultra', NULL),
('device_models', 'xiaomi_14', 'Xiaomi 14', NULL),
('device_models', 'xiaomi_13_pro', 'Xiaomi 13 Pro', NULL),
('device_models', 'xiaomi_13', 'Xiaomi 13', NULL),
('device_models', 'xiaomi_12_pro', 'Xiaomi 12 Pro', NULL),
('device_models', 'xiaomi_12', 'Xiaomi 12', NULL),
('device_models', 'redmi_note_13_pro', 'Redmi Note 13 Pro', NULL),
('device_models', 'redmi_note_13', 'Redmi Note 13', NULL),
('device_models', 'redmi_note_12_pro', 'Redmi Note 12 Pro', NULL),
('device_models', 'redmi_note_12', 'Redmi Note 12', NULL),
('device_models', 'poco_x5_pro', 'POCO X5 Pro', NULL),
('device_models', 'poco_f5', 'POCO F5', NULL),

-- Huawei Series
('device_models', 'huawei_p60_pro', 'Huawei P60 Pro', NULL),
('device_models', 'huawei_p50_pro', 'Huawei P50 Pro', NULL),
('device_models', 'huawei_mate_50_pro', 'Huawei Mate 50 Pro', NULL),
('device_models', 'huawei_nova_11', 'Huawei Nova 11', NULL),

-- OnePlus Series
('device_models', 'oneplus_12', 'OnePlus 12', NULL),
('device_models', 'oneplus_11', 'OnePlus 11', NULL),
('device_models', 'oneplus_10_pro', 'OnePlus 10 Pro', NULL),
('device_models', 'oneplus_9_pro', 'OnePlus 9 Pro', NULL),
('device_models', 'oneplus_nord_3', 'OnePlus Nord 3', NULL),

-- Oppo Series
('device_models', 'oppo_find_x6_pro', 'Oppo Find X6 Pro', NULL),
('device_models', 'oppo_reno_10_pro', 'Oppo Reno 10 Pro', NULL),
('device_models', 'oppo_a98', 'Oppo A98', NULL),

-- Vivo Series
('device_models', 'vivo_x90_pro', 'Vivo X90 Pro', NULL),
('device_models', 'vivo_v29', 'Vivo V29', NULL),

-- Realme Series
('device_models', 'realme_11_pro', 'Realme 11 Pro', NULL),
('device_models', 'realme_c55', 'Realme C55', NULL),

-- Motorola Series
('device_models', 'moto_g84', 'Motorola Moto G84', NULL),
('device_models', 'moto_edge_40', 'Motorola Edge 40', NULL),

-- Sony Xperia Series
('device_models', 'xperia_1_v', 'Sony Xperia 1 V', NULL),
('device_models', 'xperia_5_v', 'Sony Xperia 5 V', NULL),
('device_models', 'xperia_10_v', 'Sony Xperia 10 V', NULL),

-- Nothing Series
('device_models', 'nothing_phone_2', 'Nothing Phone (2)', NULL),
('device_models', 'nothing_phone_1', 'Nothing Phone (1)', NULL),

-- Fairphone Series
('device_models', 'fairphone_5', 'Fairphone 5', NULL),
('device_models', 'fairphone_4', 'Fairphone 4', NULL)

ON CONFLICT (setting_type, setting_key, COALESCE(user_id, '00000000-0000-0000-0000-000000000000'::uuid)) 
DO NOTHING;
