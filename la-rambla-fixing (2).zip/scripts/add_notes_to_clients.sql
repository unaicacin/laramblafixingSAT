-- Add notes column to clients table
ALTER TABLE public.clients 
ADD COLUMN notes TEXT;

-- Update RLS policies to include the new column (they should already work since they use user_id)
-- No additional RLS changes needed as existing policies cover all columns
