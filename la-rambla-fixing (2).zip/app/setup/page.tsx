import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Database, CheckCircle, AlertTriangle } from "lucide-react"

export default async function SetupPage() {
  const supabase = await createClient()
  const { data, error } = await supabase.auth.getUser()

  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Check if database is already set up by trying to query the repairs table
  const { data: repairs, error: repairsError } = await supabase.from("repairs").select("id").limit(1)

  const isDatabaseSetup = !repairsError

  return (
    <div className="container mx-auto p-6">
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <div
            className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center mb-4 ${
              isDatabaseSetup ? "bg-green-100" : "bg-blue-100"
            }`}
          >
            {isDatabaseSetup ? (
              <CheckCircle className="w-6 h-6 text-green-600" />
            ) : (
              <Database className="w-6 h-6 text-blue-600" />
            )}
          </div>
          <CardTitle className="text-xl">
            {isDatabaseSetup ? "Base de Datos Configurada" : "Configuración de Base de Datos"}
          </CardTitle>
          <CardDescription>
            {isDatabaseSetup
              ? "Tu base de datos está lista para usar."
              : "Configura las tablas necesarias para La Rambla Fixing."}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {isDatabaseSetup ? (
            <div className="text-center space-y-4">
              <p className="text-sm text-muted-foreground">✅ Todas las tablas están creadas y listas para usar.</p>
              <div className="flex gap-2 justify-center">
                <Button asChild className="bg-[#A6C946] hover:bg-[#8fb03a] text-white">
                  <a href="/dashboard">Ir al Dashboard</a>
                </Button>
                <Button asChild variant="outline">
                  <a href="/repairs">Ver Reparaciones</a>
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-amber-800">Configuración Requerida</h4>
                    <p className="text-sm text-amber-700 mt-1">
                      Las tablas de la base de datos no han sido creadas. Sigue estos pasos para configurar el sistema:
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <h4 className="font-medium mb-3">Pasos para Configurar:</h4>
                <ol className="text-sm space-y-2 list-decimal list-inside text-muted-foreground">
                  <li>
                    En v0, ve a la pestaña de <strong>Scripts</strong>
                  </li>
                  <li>
                    Busca y ejecuta el script <code className="bg-background px-1 rounded">init_database.sql</code>
                  </li>
                  <li>Espera a que se complete la ejecución</li>
                  <li>Recarga esta página para verificar</li>
                </ol>
              </div>

              <div className="text-center">
                <form action="/setup" method="get">
                  <Button type="submit" className="bg-[#A6C946] hover:bg-[#8fb03a] text-white">
                    Verificar Configuración
                  </Button>
                </form>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
