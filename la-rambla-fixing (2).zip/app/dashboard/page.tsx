import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Sidebar } from "@/components/layout/sidebar"
import { DashboardContent } from "./dashboard-content"

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data, error } = await supabase.auth.getUser()

  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Fetch dashboard statistics
  const [{ data: clients }, { data: repairs }, { data: stock }, { data: recentRepairs }, { data: profile }] =
    await Promise.all([
      supabase.from("clients").select("id").eq("user_id", data.user.id),
      supabase.from("repairs").select("id, estado, coste_reparacion, created_at").eq("user_id", data.user.id),
      supabase.from("stock").select("id, quantity, min_quantity, price").eq("user_id", data.user.id),
      supabase
        .from("repairs")
        .select(`
        id,
        device,
        estado,
        coste_reparacion,
        created_at,
        clients (name)
      `)
        .eq("user_id", data.user.id)
        .order("created_at", { ascending: false })
        .limit(5),
      supabase.from("profiles").select("business_name").eq("id", data.user.id).single(),
    ])

  const dashboardData = {
    totalClients: clients?.length || 0,
    totalRepairs: repairs?.length || 0,
    activeRepairs: repairs?.filter((r) => r.estado !== "Entregado").length || 0,
    completedRepairs: repairs?.filter((r) => r.estado === "Reparado" || r.estado === "Entregado").length || 0,
    totalStock: stock?.length || 0,
    lowStockItems: stock?.filter((s) => s.quantity <= s.min_quantity).length || 0,
    monthlyRevenue:
      repairs
        ?.filter((r) => {
          const repairDate = new Date(r.created_at)
          const now = new Date()
          return (
            repairDate.getMonth() === now.getMonth() &&
            repairDate.getFullYear() === now.getFullYear() &&
            (r.estado === "Reparado" || r.estado === "Entregado")
          )
        })
        .reduce((sum, r) => sum + (r.coste_reparacion || 0), 0) || 0,
    inventoryValue: stock?.reduce((sum, s) => sum + (s.price || 0) * s.quantity, 0) || 0,
    recentRepairs: recentRepairs || [],
    businessName: profile?.business_name || "La Rambla Fixing",
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-y-auto">
        <DashboardContent data={dashboardData} />
      </main>
    </div>
  )
}
