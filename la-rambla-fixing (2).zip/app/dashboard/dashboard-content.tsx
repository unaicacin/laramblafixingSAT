"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Users,
  Wrench,
  Package,
  AlertTriangle,
  TrendingUp,
  Euro,
  Plus,
  Eye,
  CheckCircle,
  Truck,
  Clock,
  FlaskConical,
  Shield,
  XCircle,
} from "lucide-react"
import Link from "next/link"

interface Client {
  name: string
}

interface RecentRepair {
  id: string
  device: string
  estado: string
  coste_reparacion?: number
  created_at: string
  clients: Client
}

interface DashboardData {
  totalClients: number
  totalRepairs: number
  activeRepairs: number
  completedRepairs: number
  totalStock: number
  lowStockItems: number
  monthlyRevenue: number
  inventoryValue: number
  recentRepairs: RecentRepair[]
  businessName: string
}

interface DashboardContentProps {
  data: DashboardData
}

const getStatusColor = (status: string) => {
  switch (status.toLowerCase()) {
    case "reparado":
      return "bg-green-100 text-green-800 hover:bg-green-100"
    case "entregado":
      return "bg-blue-100 text-blue-800 hover:bg-blue-100"
    case "cursando garantía":
      return "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
    case "laboratorio":
      return "bg-purple-100 text-purple-800 hover:bg-purple-100"
    case "sin reparación":
      return "bg-red-100 text-red-800 hover:bg-red-100"
    case "en reparación":
    default:
      return "bg-orange-100 text-orange-800 hover:bg-orange-100"
  }
}

export function DashboardContent({ data }: DashboardContentProps) {
  return (
    <div className="flex-1 space-y-6 p-4 md:p-8 pt-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
          <p className="text-muted-foreground">Bienvenido a {data.businessName} - Resumen de tu negocio</p>
        </div>
        <div className="flex gap-2">
          <Button asChild>
            <Link href="/repairs">
              <Plus className="mr-2 h-4 w-4" />
              Nueva Reparación
            </Link>
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Clientes</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalClients}</div>
            <p className="text-xs text-muted-foreground">Clientes registrados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Reparaciones Activas</CardTitle>
            <Wrench className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{data.activeRepairs}</div>
            <p className="text-xs text-muted-foreground">En proceso</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Stock Bajo</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{data.lowStockItems}</div>
            <p className="text-xs text-muted-foreground">Requieren reposición</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ingresos del Mes</CardTitle>
            <Euro className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">€{data.monthlyRevenue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Reparaciones completadas</p>
          </CardContent>
        </Card>
      </div>

      {/* Secondary Metrics */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Reparaciones</CardTitle>
            <Wrench className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalRepairs}</div>
            <p className="text-xs text-muted-foreground">{data.completedRepairs} completadas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Productos en Stock</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalStock}</div>
            <p className="text-xs text-muted-foreground">Productos registrados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valor del Inventario</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">€{data.inventoryValue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Valor total del stock</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Recent Repairs */}
        <Card>
          <CardHeader>
            <CardTitle>Reparaciones Recientes</CardTitle>
            <CardDescription>Últimas 5 reparaciones registradas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.recentRepairs.length > 0 ? (
                data.recentRepairs.map((repair) => (
                  <div key={repair.id} className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium leading-none">{repair.device}</p>
                      <p className="text-sm text-muted-foreground">{repair.clients.name}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getStatusColor(repair.estado)}>{repair.estado}</Badge>
                      {repair.coste_reparacion && (
                        <span className="text-sm font-medium">€{repair.coste_reparacion.toFixed(2)}</span>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-center text-muted-foreground py-4">No hay reparaciones registradas</p>
              )}
            </div>
            {data.recentRepairs.length > 0 && (
              <div className="mt-4">
                <Button variant="outline" className="w-full bg-transparent" asChild>
                  <Link href="/repairs">
                    <Eye className="mr-2 h-4 w-4" />
                    Ver Todas las Reparaciones
                  </Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Accesos Directos</CardTitle>
            <CardDescription>Filtrar reparaciones por estado</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              <Button asChild className="justify-start">
                <Link href="/repairs">
                  <Plus className="mr-2 h-4 w-4" />
                  Nueva Reparación
                </Link>
              </Button>

              <Button variant="outline" asChild className="justify-start bg-transparent">
                <Link href="/repairs?estado=en reparación">
                  <Clock className="mr-2 h-4 w-4 text-orange-600" />
                  En Reparación
                </Link>
              </Button>

              <Button variant="outline" asChild className="justify-start bg-transparent">
                <Link href="/repairs?estado=reparado">
                  <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                  Reparado
                </Link>
              </Button>

              <Button variant="outline" asChild className="justify-start bg-transparent">
                <Link href="/repairs?estado=entregado">
                  <Truck className="mr-2 h-4 w-4 text-blue-600" />
                  Entregado
                </Link>
              </Button>

              <Button variant="outline" asChild className="justify-start bg-transparent">
                <Link href="/repairs?estado=laboratorio">
                  <FlaskConical className="mr-2 h-4 w-4 text-purple-600" />
                  Laboratorio
                </Link>
              </Button>

              <Button variant="outline" asChild className="justify-start bg-transparent">
                <Link href="/repairs?estado=cursando garantía">
                  <Shield className="mr-2 h-4 w-4 text-yellow-600" />
                  Cursando Garantía
                </Link>
              </Button>

              <Button variant="outline" asChild className="justify-start bg-transparent">
                <Link href="/repairs?estado=sin reparación">
                  <XCircle className="mr-2 h-4 w-4 text-red-600" />
                  Sin Reparación
                </Link>
              </Button>

              <div className="border-t pt-3 mt-2">
                <Button variant="outline" asChild className="justify-start bg-transparent w-full mb-2">
                  <Link href="/clients">
                    <Users className="mr-2 h-4 w-4" />
                    Gestionar Clientes
                  </Link>
                </Button>

                <Button variant="outline" asChild className="justify-start bg-transparent w-full">
                  <Link href="/stock">
                    <Package className="mr-2 h-4 w-4" />
                    Gestionar Stock
                  </Link>
                </Button>

                {data.lowStockItems > 0 && (
                  <Button
                    variant="outline"
                    asChild
                    className="justify-start border-yellow-200 bg-yellow-50 hover:bg-yellow-100 w-full mt-2"
                  >
                    <Link href="/stock">
                      <AlertTriangle className="mr-2 h-4 w-4 text-yellow-600" />
                      Ver Stock Bajo ({data.lowStockItems})
                    </Link>
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Status Overview */}
      {data.totalRepairs > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Resumen de Estados</CardTitle>
            <CardDescription>Distribución actual de las reparaciones por estado</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center text-muted-foreground">
              <p>Funcionalidad de gráficos disponible en futuras actualizaciones</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
