import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { StockContent } from "./stock-content"

export default async function StockPage() {
  const supabase = await createClient()
  const { data, error } = await supabase.auth.getUser()

  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Fetch stock items
  const { data: stock, error: stockError } = await supabase
    .from("stock")
    .select("*")
    .eq("user_id", data.user.id)
    .order("name")

  if (stockError) {
    console.error("Error fetching stock:", stockError)
  }

  return <StockContent initialStock={stock || []} />
}
