"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Edit, Trash2, AlertTriangle, Package } from "lucide-react"
import { StockForm } from "@/components/stock/stock-form"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"

interface StockItem {
  id: string
  name: string
  description?: string
  category?: string
  quantity: number
  min_quantity: number
  price?: number
  supplier?: string
  created_at: string
}

interface StockContentProps {
  initialStock: StockItem[]
}

export function StockContent({ initialStock }: StockContentProps) {
  const [stock, setStock] = useState<StockItem[]>(initialStock)
  const [searchTerm, setSearchTerm] = useState("")
  const [showForm, setShowForm] = useState(false)
  const [editingItem, setEditingItem] = useState<StockItem | undefined>()
  const router = useRouter()
  const supabase = createClient()

  const filteredStock = stock.filter(
    (item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.category?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.supplier?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const lowStockItems = stock.filter((item) => item.quantity <= item.min_quantity)

  const handleDelete = async (itemId: string) => {
    if (!confirm("¿Estás seguro de que quieres eliminar este producto?")) return

    try {
      const { error } = await supabase.from("stock").delete().eq("id", itemId)

      if (error) throw error

      setStock(stock.filter((item) => item.id !== itemId))
    } catch (error) {
      console.error("Error deleting stock item:", error)
    }
  }

  const handleFormSuccess = () => {
    router.refresh()
    // Refetch stock
    const fetchStock = async () => {
      const { data } = await supabase.from("stock").select("*").order("name")
      if (data) setStock(data)
    }
    fetchStock()
  }

  const getStockStatus = (item: StockItem) => {
    if (item.quantity === 0) {
      return { label: "Sin Stock", color: "bg-red-100 text-red-800 hover:bg-red-100" }
    }
    if (item.quantity <= item.min_quantity) {
      return { label: "Stock Bajo", color: "bg-yellow-100 text-yellow-800 hover:bg-yellow-100" }
    }
    return { label: "En Stock", color: "bg-green-100 text-green-800 hover:bg-green-100" }
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Stock</h2>
          <p className="text-muted-foreground">Gestiona el inventario de repuestos y componentes</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Nuevo Producto
        </Button>
      </div>

      {/* Low Stock Alert */}
      {lowStockItems.length > 0 && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-yellow-800">
              <AlertTriangle className="h-5 w-5" />
              Alerta de Stock Bajo
            </CardTitle>
            <CardDescription className="text-yellow-700">
              {lowStockItems.length} producto{lowStockItems.length > 1 ? "s" : ""} con stock bajo o agotado
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {lowStockItems.slice(0, 3).map((item) => (
                <div key={item.id} className="flex items-center justify-between text-sm">
                  <span className="font-medium">{item.name}</span>
                  <span className="text-yellow-700">
                    {item.quantity} / {item.min_quantity} mín.
                  </span>
                </div>
              ))}
              {lowStockItems.length > 3 && (
                <p className="text-sm text-yellow-700">Y {lowStockItems.length - 3} más...</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stock Statistics */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Productos</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stock.length}</div>
            <p className="text-xs text-muted-foreground">Productos registrados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Stock Bajo</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{lowStockItems.length}</div>
            <p className="text-xs text-muted-foreground">Requieren reposición</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valor Total</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              €{stock.reduce((total, item) => total + (item.price || 0) * item.quantity, 0).toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">Valor del inventario</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Inventario</CardTitle>
          <CardDescription>Lista completa de productos en stock</CardDescription>
          <div className="flex items-center space-x-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar productos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Producto</TableHead>
                <TableHead>Categoría</TableHead>
                <TableHead>Cantidad</TableHead>
                <TableHead>Stock Mín.</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Precio</TableHead>
                <TableHead>Proveedor</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStock.map((item) => {
                const status = getStockStatus(item)
                return (
                  <TableRow key={item.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{item.name}</div>
                        {item.description && <div className="text-sm text-muted-foreground">{item.description}</div>}
                      </div>
                    </TableCell>
                    <TableCell>{item.category || "-"}</TableCell>
                    <TableCell className="font-medium">{item.quantity}</TableCell>
                    <TableCell>{item.min_quantity}</TableCell>
                    <TableCell>
                      <Badge className={status.color}>{status.label}</Badge>
                    </TableCell>
                    <TableCell>{item.price ? `€${item.price.toFixed(2)}` : "-"}</TableCell>
                    <TableCell>{item.supplier || "-"}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setEditingItem(item)
                            setShowForm(true)
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDelete(item.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
              {filteredStock.length === 0 && (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8">
                    No se encontraron productos
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <StockForm
        item={editingItem}
        open={showForm}
        onOpenChange={(open) => {
          setShowForm(open)
          if (!open) setEditingItem(undefined)
        }}
        onSuccess={handleFormSuccess}
      />
    </div>
  )
}
