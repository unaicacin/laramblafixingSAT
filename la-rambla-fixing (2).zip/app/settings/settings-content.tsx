"use client"

import { useState } from "react"
import { SettingsSection } from "@/components/settings/settings-section"
import { ProfileSettings } from "@/components/settings/profile-settings"
import { createClient } from "@/lib/supabase/client"

interface Setting {
  id: string
  setting_type: string
  setting_key: string
  setting_value: string
  is_default: boolean
}

interface SettingsContentProps {
  initialSettings: Setting[]
}

export function SettingsContent({ initialSettings }: SettingsContentProps) {
  const [settings, setSettings] = useState<Setting[]>(initialSettings)
  const supabase = createClient()

  const handleUpdate = async () => {
    // Refetch settings
    const { data } = await supabase.from("settings").select("*").order("setting_type").order("setting_value")

    if (data) setSettings(data)
  }

  const getSettingsByType = (type: string) => {
    return settings.filter((setting) => setting.setting_type === type)
  }

  return (
    <div className="flex-1 space-y-6 p-4 md:p-8 pt-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Configuración</h2>
        <p className="text-muted-foreground">Personaliza las opciones del sistema según tus necesidades</p>
      </div>

      <div className="grid gap-6">
        {/* Profile Settings */}
        <ProfileSettings />

        {/* Repair States */}
        <SettingsSection
          title="Estados de Reparación"
          description="Configura los diferentes estados que puede tener una reparación"
          settingType="repair_states"
          settings={getSettingsByType("repair_states")}
          onUpdate={handleUpdate}
        />

        {/* Diagnosis Types */}
        <SettingsSection
          title="Tipos de Diagnóstico"
          description="Configura los diagnósticos más comunes para autocompletar"
          settingType="diagnosis_types"
          settings={getSettingsByType("diagnosis_types")}
          onUpdate={handleUpdate}
        />

        {/* Device Models */}
        <SettingsSection
          title="Modelos de Dispositivos"
          description="Configura los modelos de dispositivos más comunes para autocompletar"
          settingType="device_models"
          settings={getSettingsByType("device_models")}
          onUpdate={handleUpdate}
        />
      </div>
    </div>
  )
}
