import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { SettingsContent } from "./settings-content"

export default async function SettingsPage() {
  const supabase = await createClient()
  const { data, error } = await supabase.auth.getUser()

  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Fetch all settings
  const { data: settings, error: settingsError } = await supabase
    .from("settings")
    .select("*")
    .eq("user_id", data.user.id)
    .order("category")
    .order("key")

  if (settingsError) {
    console.error("Error fetching settings:", settingsError)
  }

  return <SettingsContent initialSettings={settings || []} />
}
