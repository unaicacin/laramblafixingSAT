import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { ClientsContent } from "./clients-content"

export default async function ClientsPage() {
  const supabase = await createClient()
  const { data, error } = await supabase.auth.getUser()

  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Fetch clients
  const { data: clients, error: clientsError } = await supabase
    .from("clients")
    .select("*")
    .eq("user_id", data.user.id)
    .order("created_at", { ascending: false })

  if (clientsError) {
    console.error("Error fetching clients:", clientsError)
  }

  return <ClientsContent initialClients={clients || []} />
}
