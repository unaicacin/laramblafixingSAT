"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Edit, Trash2, Eye } from "lucide-react"
import { RepairForm } from "@/components/repairs/repair-form"
import { RepairDetails } from "@/components/repairs/repair-details"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"

interface Client {
  id: string
  name: string
  phone?: string
  email?: string
}

interface Repair {
  id: string
  client_id: string
  device: string
  diagnostico?: string
  observaciones?: string
  coste_reparacion?: number
  estado: string
  notas_tecnico?: string
  created_at: string
  clients: Client
}

interface RepairsContentProps {
  initialRepairs: Repair[]
}

const getStatusColor = (status: string) => {
  switch (status.toLowerCase()) {
    case "reparado":
      return "bg-green-100 text-green-800 hover:bg-green-100"
    case "entregado":
      return "bg-blue-100 text-blue-800 hover:bg-blue-100"
    case "cursando garantía":
      return "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
    case "laboratorio":
      return "bg-purple-100 text-purple-800 hover:bg-purple-100"
    case "sin reparación":
      return "bg-red-100 text-red-800 hover:bg-red-100"
    case "en reparación":
    default:
      return "bg-orange-100 text-orange-800 hover:bg-orange-100"
  }
}

export function RepairsContent({ initialRepairs }: RepairsContentProps) {
  const [repairs, setRepairs] = useState<Repair[]>(initialRepairs)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("")
  const [showForm, setShowForm] = useState(false)
  const [showDetails, setShowDetails] = useState(false)
  const [editingRepair, setEditingRepair] = useState<Repair | undefined>()
  const [selectedRepair, setSelectedRepair] = useState<Repair | undefined>()
  const router = useRouter()
  const supabase = createClient()
  const searchParams = useSearchParams()

  useEffect(() => {
    const status = searchParams.get("estado")
    if (status) {
      setStatusFilter(status)
    }
  }, [searchParams])

  const filteredRepairs = repairs.filter((repair) => {
    const matchesSearch =
      repair.device.toLowerCase().includes(searchTerm.toLowerCase()) ||
      repair.clients.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      repair.diagnostico?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      repair.estado.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = !statusFilter || repair.estado.toLowerCase() === statusFilter.toLowerCase()

    return matchesSearch && matchesStatus
  })

  const handleDelete = async (repairId: string) => {
    if (!confirm("¿Estás seguro de que quieres eliminar esta reparación?")) return

    try {
      const { error } = await supabase.from("repairs").delete().eq("id", repairId)

      if (error) throw error

      setRepairs(repairs.filter((repair) => repair.id !== repairId))
    } catch (error) {
      console.error("Error deleting repair:", error)
    }
  }

  const handleFormSuccess = () => {
    router.refresh()
    const fetchRepairs = async () => {
      const { data } = await supabase
        .from("repairs")
        .select(`
          *,
          clients (
            id,
            name,
            phone,
            email
          )
        `)
        .order("created_at", { ascending: false })
      if (data) setRepairs(data)
    }
    fetchRepairs()
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Reparaciones</h2>
          <p className="text-muted-foreground">
            {statusFilter
              ? `Reparaciones con estado: ${statusFilter}`
              : "Gestiona todas las reparaciones de dispositivos"}
          </p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Nueva Reparación
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Reparaciones</CardTitle>
          <CardDescription>
            {statusFilter
              ? `Mostrando reparaciones filtradas por: ${statusFilter}`
              : "Todas las reparaciones registradas en el sistema"}
          </CardDescription>
          <div className="flex items-center space-x-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar reparaciones..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
            {statusFilter && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setStatusFilter("")
                  router.push("/repairs")
                }}
              >
                Limpiar Filtro
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cliente</TableHead>
                <TableHead>Dispositivo</TableHead>
                <TableHead>Diagnóstico</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Coste</TableHead>
                <TableHead>Fecha</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRepairs.map((repair) => (
                <TableRow key={repair.id}>
                  <TableCell className="font-medium">{repair.clients.name}</TableCell>
                  <TableCell>{repair.device}</TableCell>
                  <TableCell>{repair.diagnostico || "-"}</TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(repair.estado)}>{repair.estado}</Badge>
                  </TableCell>
                  <TableCell>{repair.coste_reparacion ? `€${repair.coste_reparacion.toFixed(2)}` : "-"}</TableCell>
                  <TableCell>{new Date(repair.created_at).toLocaleDateString()}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedRepair(repair)
                          setShowDetails(true)
                        }}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEditingRepair(repair)
                          setShowForm(true)
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleDelete(repair.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {filteredRepairs.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    No se encontraron reparaciones
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <RepairForm
        repair={editingRepair}
        open={showForm}
        onOpenChange={(open) => {
          setShowForm(open)
          if (!open) setEditingRepair(undefined)
        }}
        onSuccess={handleFormSuccess}
      />

      <RepairDetails
        repair={selectedRepair}
        open={showDetails}
        onOpenChange={(open) => {
          setShowDetails(open)
          if (!open) setSelectedRepair(undefined)
        }}
      />
    </div>
  )
}
