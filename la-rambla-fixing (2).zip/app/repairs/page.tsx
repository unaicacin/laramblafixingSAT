import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { RepairsContent } from "./repairs-content"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle } from "lucide-react"

export default async function RepairsPage() {
  const supabase = await createClient()
  const { data, error } = await supabase.auth.getUser()

  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Fetch repairs with client information
  const { data: repairs, error: repairsError } = await supabase
    .from("repairs")
    .select(`
      *,
      clients (
        id,
        name,
        phone,
        email
      )
    `)
    .eq("user_id", data.user.id)
    .order("created_at", { ascending: false })

  if (repairsError) {
    console.error("Error fetching repairs:", repairsError)

    // Check if it's a table not found error
    if (repairsError.message?.includes("does not exist") || repairsError.message?.includes("schema cache")) {
      return (
        <div className="container mx-auto p-6">
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-4">
                <AlertTriangle className="w-6 h-6 text-amber-600" />
              </div>
              <CardTitle className="text-xl">Base de Datos No Configurada</CardTitle>
              <CardDescription>Las tablas de la base de datos no han sido creadas aún.</CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-sm text-muted-foreground">
                Para usar el sistema de reparaciones, primero necesitas configurar la base de datos.
              </p>
              <div className="flex gap-2 justify-center">
                <Button asChild className="bg-[#A6C946] hover:bg-[#8fb03a] text-white">
                  <a href="/setup">Configurar Base de Datos</a>
                </Button>
                <Button asChild variant="outline">
                  <a href="/dashboard">Volver al Dashboard</a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )
    }

    // For other errors, show a generic error message
    return (
      <div className="container mx-auto p-6">
        <Card className="max-w-2xl mx-auto">
          <CardHeader className="text-center">
            <CardTitle className="text-xl text-red-600">Error</CardTitle>
            <CardDescription>Ocurrió un error al cargar las reparaciones.</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-sm text-muted-foreground mb-4">{repairsError.message}</p>
            <form action="/repairs" method="get">
              <Button type="submit" variant="outline">
                Intentar de Nuevo
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  return <RepairsContent initialRepairs={repairs || []} />
}
