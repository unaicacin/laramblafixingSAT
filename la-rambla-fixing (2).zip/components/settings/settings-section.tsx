"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, X, Edit2, Check } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface Setting {
  id: string
  key: string
  value: string
  is_default: boolean
}

interface SettingsSectionProps {
  title: string
  description: string
  settingType: string
  settings: Setting[]
  onUpdate: () => void
}

export function SettingsSection({ title, description, settingType, settings, onUpdate }: SettingsSectionProps) {
  const [newValue, setNewValue] = useState("")
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editValue, setEditValue] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClient()

  const handleAdd = async () => {
    if (!newValue.trim()) return

    setIsLoading(true)
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Usuario no autenticado")

      const settingKey = newValue
        .toLowerCase()
        .replace(/\s+/g, "_")
        .replace(/[^a-z0-9_]/g, "")

      const { error } = await supabase.from("settings").insert({
        category: settingType,
        key: settingKey,
        value: newValue.trim(),
        is_default: false,
        user_id: user.id,
      })

      if (error) throw error

      setNewValue("")
      onUpdate()
    } catch (error) {
      console.error("Error adding setting:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleEdit = async (id: string) => {
    if (!editValue.trim()) return

    setIsLoading(true)
    try {
      const { error } = await supabase
        .from("settings")
        .update({
          value: editValue.trim(),
        })
        .eq("id", id)

      if (error) throw error

      setEditingId(null)
      setEditValue("")
      onUpdate()
    } catch (error) {
      console.error("Error updating setting:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleDelete = async (id: string, isDefault: boolean) => {
    if (isDefault) {
      alert("No se pueden eliminar las opciones predeterminadas")
      return
    }

    if (!confirm("¿Estás seguro de que quieres eliminar esta opción?")) return

    try {
      const { error } = await supabase.from("settings").delete().eq("id", id)

      if (error) throw error

      onUpdate()
    } catch (error) {
      console.error("Error deleting setting:", error)
    }
  }

  const startEdit = (setting: Setting) => {
    setEditingId(setting.id)
    setEditValue(setting.value)
  }

  const cancelEdit = () => {
    setEditingId(null)
    setEditValue("")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add new setting */}
        <div className="flex gap-2">
          <Input
            placeholder={`Agregar nuevo ${title.toLowerCase()}...`}
            value={newValue}
            onChange={(e) => setNewValue(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleAdd()}
          />
          <Button onClick={handleAdd} disabled={isLoading || !newValue.trim()}>
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        {/* Settings list */}
        <div className="space-y-2">
          {settings.map((setting) => (
            <div key={setting.id} className="flex items-center justify-between p-2 border rounded-lg">
              {editingId === setting.id ? (
                <div className="flex items-center gap-2 flex-1">
                  <Input
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") handleEdit(setting.id)
                      if (e.key === "Escape") cancelEdit()
                    }}
                    className="flex-1"
                  />
                  <Button size="sm" onClick={() => handleEdit(setting.id)} disabled={isLoading}>
                    <Check className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={cancelEdit}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-2">
                    <span>{setting.value}</span>
                    {setting.is_default && <Badge variant="secondary">Predeterminado</Badge>}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" onClick={() => startEdit(setting)}>
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(setting.id, setting.is_default)}
                      disabled={setting.is_default}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </>
              )}
            </div>
          ))}
          {settings.length === 0 && (
            <p className="text-center text-muted-foreground py-4">No hay opciones configuradas</p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
