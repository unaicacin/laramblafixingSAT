"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Plus } from "lucide-react"
import { ClientForm } from "@/components/clients/client-form"

interface Client {
  id: string
  name: string
  email?: string
  phone?: string
}

interface Repair {
  id?: string
  client_id: string
  device: string
  diagnostico?: string
  observaciones?: string
  coste_reparacion?: number
  estado: string
  notas_tecnico?: string
}

interface RepairFormProps {
  repair?: Repair
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess?: () => void
}

export function RepairForm({ repair, open, onOpenChange, onSuccess }: RepairFormProps) {
  const [step, setStep] = useState(1) // Step 1: Client selection, Step 2: Repair details
  const [clients, setClients] = useState<Client[]>([])
  const [deviceModels, setDeviceModels] = useState<string[]>([])
  const [diagnosisTypes, setDiagnosisTypes] = useState<string[]>([])
  const [repairStates, setRepairStates] = useState<string[]>([])
  const [showClientForm, setShowClientForm] = useState(false)
  const [formData, setFormData] = useState<Repair>({
    client_id: repair?.client_id || "",
    device: repair?.device || "",
    diagnostico: repair?.diagnostico || "",
    observaciones: repair?.observaciones || "",
    coste_reparacion: repair?.coste_reparacion || undefined,
    estado: repair?.estado || "En Reparación",
    notas_tecnico: repair?.notas_tecnico || "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    if (open) {
      fetchData()
      if (repair) {
        setStep(2) // Skip client selection for editing
      } else {
        setStep(1) // Start with client selection for new repairs
      }
    }
  }, [open, repair])

  const fetchData = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return

      // Fetch clients
      const { data: clientsData } = await supabase
        .from("clients")
        .select("id, name, email, phone")
        .eq("user_id", user.id)
        .order("name")

      if (clientsData) setClients(clientsData)

      // Fetch settings for autocomplete
      const { data: settingsData } = await supabase
        .from("settings")
        .select("category, key, value")
        .or(`user_id.eq.${user.id},user_id.is.null`)
        .in("category", ["device_models", "diagnosis_types", "repair_states"])

      if (settingsData) {
        const deviceModelsData = settingsData.filter((s) => s.category === "device_models").map((s) => s.value)
        const diagnosisData = settingsData.filter((s) => s.category === "diagnosis_types").map((s) => s.value)
        const statesData = settingsData.filter((s) => s.category === "repair_states").map((s) => s.value)

        setDeviceModels(deviceModelsData)
        setDiagnosisTypes(diagnosisData)
        // Set default repair states if none found in database
        setRepairStates(
          statesData.length > 0
            ? statesData
            : ["En Reparación", "Reparado", "Entregado", "Cursando Garantía", "Laboratorio", "Sin Reparación"],
        )
      }
    } catch (error) {
      console.error("Error fetching data:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Usuario no autenticado")

      const repairData = {
        ...formData,
        user_id: user.id,
        updated_at: new Date().toISOString(),
      }

      if (repair?.id) {
        // Update existing repair
        const { error } = await supabase.from("repairs").update(repairData).eq("id", repair.id).eq("user_id", user.id)

        if (error) throw error
      } else {
        // Create new repair
        const { error } = await supabase.from("repairs").insert(repairData)

        if (error) throw error
      }

      onOpenChange(false)
      onSuccess?.()
      router.refresh()
      setStep(1) // Reset to step 1 for next use
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "Ha ocurrido un error")
    } finally {
      setIsLoading(false)
    }
  }

  const handleClientFormSuccess = () => {
    fetchData() // Refresh clients list
  }

  if (step === 1 && !repair) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Nueva Reparación - Seleccionar Cliente</DialogTitle>
            <DialogDescription>Primero selecciona el cliente para esta reparación</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="client">Cliente *</Label>
              <Select
                value={formData.client_id}
                onValueChange={(value) => setFormData({ ...formData, client_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un cliente" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map((client) => (
                    <SelectItem key={client.id} value={client.id}>
                      {client.name} {client.phone && `(${client.phone})`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button
              type="button"
              variant="outline"
              className="w-full bg-transparent"
              onClick={() => setShowClientForm(true)}
            >
              <Plus className="mr-2 h-4 w-4" />
              Agregar Nuevo Cliente
            </Button>

            {error && <p className="text-sm text-destructive">{error}</p>}

            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancelar
              </Button>
              <Button type="button" onClick={() => setStep(2)} disabled={!formData.client_id}>
                Continuar
              </Button>
            </div>
          </div>

          <ClientForm open={showClientForm} onOpenChange={setShowClientForm} onSuccess={handleClientFormSuccess} />
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{repair ? "Editar Reparación" : "Nueva Reparación - Detalles"}</DialogTitle>
          <DialogDescription>
            {repair ? "Modifica los datos de la reparación" : "Ingresa los detalles de la reparación"}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!repair && (
            <div className="grid gap-2">
              <Label>Cliente Seleccionado</Label>
              <div className="p-2 bg-muted rounded-md">
                {clients.find((c) => c.id === formData.client_id)?.name || "Cliente no encontrado"}
              </div>
            </div>
          )}

          <div className="grid gap-2">
            <Label htmlFor="device">Dispositivo *</Label>
            <Input
              id="device"
              value={formData.device}
              onChange={(e) => setFormData({ ...formData, device: e.target.value })}
              placeholder="Ej: iPhone 15 Pro, Samsung Galaxy S24..."
              list="device-models"
              required
            />
            <datalist id="device-models">
              {deviceModels.map((model, index) => (
                <option key={index} value={model} />
              ))}
            </datalist>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="diagnostico">Diagnóstico</Label>
            <Input
              id="diagnostico"
              value={formData.diagnostico}
              onChange={(e) => setFormData({ ...formData, diagnostico: e.target.value })}
              placeholder="Selecciona o escribe el diagnóstico..."
              list="diagnosis-types"
            />
            <datalist id="diagnosis-types">
              {diagnosisTypes.map((diagnosis, index) => (
                <option key={index} value={diagnosis} />
              ))}
            </datalist>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="observaciones">Observaciones</Label>
            <Textarea
              id="observaciones"
              value={formData.observaciones}
              onChange={(e) => setFormData({ ...formData, observaciones: e.target.value })}
              placeholder="Describe el problema o situación del dispositivo..."
              rows={3}
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="coste_reparacion">Coste de Reparación (€)</Label>
            <Input
              id="coste_reparacion"
              type="number"
              step="0.01"
              min="0"
              value={formData.coste_reparacion || ""}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  coste_reparacion: e.target.value ? Number.parseFloat(e.target.value) : undefined,
                })
              }
              placeholder="0.00"
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="estado">Estado de la Reparación *</Label>
            <Select value={formData.estado} onValueChange={(value) => setFormData({ ...formData, estado: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {repairStates.map((state, index) => (
                  <SelectItem key={index} value={state}>
                    {state}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="notas_tecnico">Notas del Técnico</Label>
            <Textarea
              id="notas_tecnico"
              value={formData.notas_tecnico}
              onChange={(e) => setFormData({ ...formData, notas_tecnico: e.target.value })}
              placeholder="Notas internas del técnico (no visibles para el cliente)..."
              rows={3}
            />
            <p className="text-xs text-muted-foreground">Estas notas no son visibles para el cliente</p>
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}

          <div className="flex justify-end gap-2">
            {!repair && step === 2 && (
              <Button type="button" variant="outline" onClick={() => setStep(1)}>
                Volver
              </Button>
            )}
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Guardando..." : "Guardar"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
