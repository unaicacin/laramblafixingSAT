"use client"

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

interface Client {
  id: string
  name: string
  phone?: string
  email?: string
}

interface Repair {
  id: string
  client_id: string
  device: string
  diagnostico?: string
  observaciones?: string
  coste_reparacion?: number
  estado: string
  notas_tecnico?: string
  created_at: string
  clients: Client
}

interface RepairDetailsProps {
  repair?: Repair
  open: boolean
  onOpenChange: (open: boolean) => void
}

const getStatusColor = (status: string) => {
  switch (status.toLowerCase()) {
    case "reparado":
      return "bg-green-100 text-green-800 hover:bg-green-100"
    case "entregado":
      return "bg-blue-100 text-blue-800 hover:bg-blue-100"
    case "cursando garantía":
      return "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
    case "laboratorio":
      return "bg-purple-100 text-purple-800 hover:bg-purple-100"
    case "sin reparación":
      return "bg-red-100 text-red-800 hover:bg-red-100"
    case "en reparación":
    default:
      return "bg-orange-100 text-orange-800 hover:bg-orange-100"
  }
}

export function RepairDetails({ repair, open, onOpenChange }: RepairDetailsProps) {
  if (!repair) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Detalles de la Reparación</DialogTitle>
          <DialogDescription>Información completa de la reparación</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Client Information */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Información del Cliente</h3>
            <div className="grid gap-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Nombre:</span>
                <span className="font-medium">{repair.clients.name}</span>
              </div>
              {repair.clients.phone && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Teléfono:</span>
                  <span>{repair.clients.phone}</span>
                </div>
              )}
              {repair.clients.email && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Email:</span>
                  <span>{repair.clients.email}</span>
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* Repair Information */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Información de la Reparación</h3>
            <div className="grid gap-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Dispositivo:</span>
                <span className="font-medium">{repair.device}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-muted-foreground">Estado:</span>
                <Badge className={getStatusColor(repair.estado)}>{repair.estado}</Badge>
              </div>

              {repair.diagnostico && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Diagnóstico:</span>
                  <span>{repair.diagnostico}</span>
                </div>
              )}

              {repair.coste_reparacion && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Coste:</span>
                  <span className="font-medium">€{repair.coste_reparacion.toFixed(2)}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span className="text-muted-foreground">Fecha de Ingreso:</span>
                <span>{new Date(repair.created_at).toLocaleDateString()}</span>
              </div>
            </div>
          </div>

          {repair.observaciones && (
            <>
              <Separator />
              <div>
                <h3 className="text-lg font-semibold mb-3">Observaciones</h3>
                <p className="text-sm bg-muted p-3 rounded-md">{repair.observaciones}</p>
              </div>
            </>
          )}

          {repair.notas_tecnico && (
            <>
              <Separator />
              <div>
                <h3 className="text-lg font-semibold mb-3">Notas del Técnico</h3>
                <p className="text-sm bg-yellow-50 border border-yellow-200 p-3 rounded-md">{repair.notas_tecnico}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Estas notas son internas y no son visibles para el cliente
                </p>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
