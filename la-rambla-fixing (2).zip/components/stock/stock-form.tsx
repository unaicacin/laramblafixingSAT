"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"

interface StockItem {
  id?: string
  name: string
  description?: string
  category?: string
  quantity: number
  min_quantity: number
  price?: number
  supplier?: string
}

interface StockFormProps {
  item?: StockItem
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess?: () => void
}

export function StockForm({ item, open, onOpenChange, onSuccess }: StockFormProps) {
  const [formData, setFormData] = useState<StockItem>({
    name: item?.name || "",
    description: item?.description || "",
    category: item?.category || "",
    quantity: item?.quantity || 0,
    min_quantity: item?.min_quantity || 0,
    price: item?.price || undefined,
    supplier: item?.supplier || "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Usuario no autenticado")

      if (item?.id) {
        // Update existing item
        const { error } = await supabase
          .from("stock")
          .update({
            ...formData,
            updated_at: new Date().toISOString(),
          })
          .eq("id", item.id)
          .eq("user_id", user.id)

        if (error) throw error
      } else {
        // Create new item
        const { error } = await supabase.from("stock").insert({
          ...formData,
          user_id: user.id,
        })

        if (error) throw error
      }

      onOpenChange(false)
      onSuccess?.()
      router.refresh()
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "Ha ocurrido un error")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{item ? "Editar Producto" : "Nuevo Producto"}</DialogTitle>
          <DialogDescription>
            {item ? "Modifica los datos del producto" : "Ingresa los datos del nuevo producto"}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Nombre del Producto *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Ej: Pantalla iPhone 15, Batería Samsung S24..."
              required
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="description">Descripción</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Descripción detallada del producto..."
              rows={2}
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="category">Categoría</Label>
            <Input
              id="category"
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              placeholder="Ej: Pantallas, Baterías, Cargadores..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="quantity">Cantidad Actual *</Label>
              <Input
                id="quantity"
                type="number"
                min="0"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: Number.parseInt(e.target.value) || 0 })}
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="min_quantity">Stock Mínimo *</Label>
              <Input
                id="min_quantity"
                type="number"
                min="0"
                value={formData.min_quantity}
                onChange={(e) => setFormData({ ...formData, min_quantity: Number.parseInt(e.target.value) || 0 })}
                required
              />
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="price">Precio (€)</Label>
            <Input
              id="price"
              type="number"
              step="0.01"
              min="0"
              value={formData.price || ""}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  price: e.target.value ? Number.parseFloat(e.target.value) : undefined,
                })
              }
              placeholder="0.00"
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="supplier">Proveedor</Label>
            <Input
              id="supplier"
              value={formData.supplier}
              onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
              placeholder="Nombre del proveedor..."
            />
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Guardando..." : "Guardar"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
